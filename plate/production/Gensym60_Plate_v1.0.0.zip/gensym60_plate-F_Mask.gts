G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,9.0.5*
G04 #@! TF.CreationDate,2025-11-18T22:24:49+09:00*
G04 #@! TF.ProjectId,gensym60_plate,72656178-6973-4363-905f-706c6174652e,v1.0.0*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 9.0.5) date 2025-11-18 22:24:49*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 APERTURE END LIST*
M02*
